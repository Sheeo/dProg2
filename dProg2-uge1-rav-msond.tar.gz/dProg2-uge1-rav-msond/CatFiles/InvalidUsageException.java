class InvalidUsageException extends RuntimeException {
	public InvalidUsageException(String message) {
		super(message);
	}
}
