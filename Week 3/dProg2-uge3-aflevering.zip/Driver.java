public class Driver {
	public static void main(String[] args) {
		IconCrafterProgram prog = new IconCrafterProgram(args);
		prog.execute();
	}
}
